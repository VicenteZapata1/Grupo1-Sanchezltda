from django.conf.urls import url
from Materiales import views

urlpatterns = [
    url(r'^$',views.HomePageView.as_view(),name="index"),
    url(r'cursos/', views,HomeMaterialesView.as_view(),name="Materiales"),
]
