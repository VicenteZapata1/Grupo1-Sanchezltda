from django.shortcuts import render
from django.views.generic import TemplatesView
from .model import  Material, MaterialDisponible

class HomePageView(TemplateView):
	def get(self, request, **kwargs):
		return render(request, 'index.html',context=None)

class HomeMaterialesView(TemplateView):
	def get(self, request, **kwargs):
		MaterialDisponible=MaterialDisponible()
		return render(request ,'Materiales.html', {'Materiales': MaterialDisponible.obtenerMateriales()})

# Create your views here.
