from django.db import models

class Material:
	def __init__(self,sigla,nombre,cantidad):
		self.sigla=sigla
		self.nombre=nombre
		self.cantidad=cantidad

class MaterialDisponible:
	def __init__(self):
		self.Materiales=[]
		self.Materiales.append(Material("Bot","Botas","4"))
		self.Materiales.append(Material("Gua","Guantes","20"))
		self.Materiales.append(Material("Apa","AntiParras","50"))
		self.Materiales.append(Material("Tdo","Tapones de oidos","60"))
		
# Create your models here.
