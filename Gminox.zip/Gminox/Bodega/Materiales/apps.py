from django.apps import AppConfig


class MaterialesConfig(AppConfig):
    name = 'Materiales'
