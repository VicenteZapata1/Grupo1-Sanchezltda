from django.conf.urls import url,re_path
from django.urls import path,include
from materiales import views

urlpatterns = [
    url(r'^$',views.HomePageView.as_view(),name='index'),
    url(r'materiales/', views.HomeMaterialesView.as_view(),name='materiales'),
    url(r'epp/', views.HomeEPPView.as_view(),name='epp'),
    url(r'herramientas/', views.HomeHerramientasView.as_view(),name='herramientas'),
    url(r'insumos/', views.HomeInsumosView.as_view(),name='insumos'),
    path('accounts/', include('accounts.urls')),
    path('accounts/', include('django.contrib.auth.urls')),
    re_path(r'^material/(?P<identificador>[0-9]{1})/$', views.DetalleMaterialView.as_view(),name="detalle")

]
