from django.db import models

class Material:
    def __init__(self,identificador,nombre,cantidad,largo,ancho,espesor):
        self.identificador=identificador
        self.nombre=nombre
        self.cantidad=cantidad
        self.largo=largo
        self.ancho=ancho
        self.espesor=espesor

class EPP:
    def __init__(self,identificadorE,nombreE,cantidadE):
        self.identificadorE=identificadorE
        self.nombreE=nombreE
        self.cantidadE=cantidadE

class Herramienta:
    def __init__(self,identificadorH,nombreH,cantidadH):
        self.identificadorH=identificadorH
        self.nombreH=nombreH
        self.cantidadH=cantidadH

class Insumo:
    def __init__(self,identificadorI,nombreI,medidaI,cantidadI):
        self.identificadorI=identificadorI
        self.nombreI=nombreI
        self.medidaI=medidaI
        self.cantidadI=cantidadI

class MaterialFactory:
    def __init__(self):
        self.materiales=[]
        self.materiales.append(Material("1","Acero Carbono",5,1000,3000,"0.8"))
        self.materiales.append(Material("2","Acero Inoxidable",10,1000,2500,10))

    def obtenerMateriales(self):
        return self.materiales

    def getMaterial(self,identificador):
        for material in self.materiales:
            if material.identificador==identificador:
                return material
        return None

class EPPFactory:
    def __init__(self):
        self.epp=[]
        self.epp.append(EPP(1,"guantes",30))
        self.epp.append(EPP(2,"AntiParras",40))
        self.epp.append(EPP(3,"Botas de Seguridad",5))
        self.epp.append(EPP(4,"Tapones de Oido",100))
    
    def obtenerEPP(self):
        return self.epp

class HerramientasFactory:
    def __init__(self):
        self.herramientas=[]
        self.herramientas.append(Herramienta(1,"Martillo",10))
        self.herramientas.append(Herramienta(2,"Taladro",4))
        self.herramientas.append(Herramienta(3,"Llave hexagonal",20))
        self.herramientas.append(Herramienta(4,"Lorito",2))
    
    def obtenerHerramientas(self):
        return self.herramientas

class InsumoFactory:
    def __init__(self):
        self.insumos=[]
        self.insumos.append(Insumo(1,"Disco Traslapado","3/4",30))
        self.insumos.append(Insumo(2,"Banda de Lija","60 granos",100))
        self.insumos.append(Insumo(3,"Banda de Lija","120 granos",80))
        self.insumos.append(Insumo(4,"gas neon","",3))

    def obtenerInsumos(self):
        return self.insumos