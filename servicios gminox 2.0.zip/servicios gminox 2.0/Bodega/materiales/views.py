from django.shortcuts import render
from django.views.generic import TemplateView
from .models import Material, MaterialFactory, EPP, EPPFactory, Herramienta, HerramientasFactory, Insumo, InsumoFactory
from django.contrib.auth.mixins import LoginRequiredMixin

class HomePageView(TemplateView):
    def get(self, request, **kwargs):
        return render(request,'index.html', context= None)

class HomeMaterialesView(LoginRequiredMixin,TemplateView):
    def get(self, request, **kwargs):
        materialFactory=MaterialFactory()
        return render(request, 'materiales.html', {'materiales': materialFactory.obtenerMateriales()})

class DetalleMaterialView(LoginRequiredMixin,TemplateView):
    def get(self, request, **kwargs):
        materialFactory=MaterialFactory()
        identficador=kwargs["identificador"]
        return render(request, 'material.html', {'material': materialFactory.getMaterial(identficador)})

class HomeEPPView(LoginRequiredMixin,TemplateView):
    def get(self, request, **kwargs):
        eppFactory=EPPFactory()
        return render(request, 'epp.html',{'epp': eppFactory.obtenerEPP()})

class HomeHerramientasView(LoginRequiredMixin,TemplateView):
    def get(self, request, **kwargs):
        herramientaFactory=HerramientasFactory()
        return render(request, 'herramientas.html',{'herramientas': herramientaFactory.obtenerHerramientas()})

class HomeInsumosView(LoginRequiredMixin,TemplateView):
    def get(self,request, **kwargs):
        insumosFactory=InsumoFactory()
        return render(request, 'insumos.html',{'insumos': insumosFactory.obtenerInsumos()}) 