from django.db import models

class Material:
	def __init__(self,identificador,sigla,nombre,espesor,largo,ancho,cantidad):
		self.identificador=identificador
		self.sigla=sigla
		self.nombre=nombre
		self.espesor=espesor
		self.largo=largo
		self.ancho=ancho
		self.cantidad=cantidad

class MaterialDisponible:
	def __init__(self):
		self.materiales=[]
		self.materiales.append(Material("1","ACC","Acero Carbono","2","1000","3000","1"))
		self.materiales.append(Material("1","ACC","Acero Carbono","2","1000","2000","2"))
		self.materiales.append(Material("2","ACI","Acero Inoxidable","2","1000","3000","1"))
		self.materiales.append(Material("2","ACI","Acero Inoxidable","8","1000","1500","2"))
		self.materiales.append(Material("3","FE","Fierro","6","1500","3000","1"))

	def obtenerMateriales(self):
		return self.materiales

