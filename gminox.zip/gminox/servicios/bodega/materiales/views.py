from django.shortcuts import render
from django.views.generic import TemplateView
from .models import Material, MaterialDisponible

class HomePageView(TemplateView):
	def get(self, request, **kwargs):
		return render(request, 'index.html', context=None)

class HomeMaterialesView(TemplateView):
	def get(self, request, **kwargs):
		materialDisponible=MaterialDisponible()
		return render(request, 'materiales.html', {'materiales': materialDisponible.obtenerMateriales()})
